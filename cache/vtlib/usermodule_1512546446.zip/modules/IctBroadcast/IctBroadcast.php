<?php
class IctBroadcast {
public function __construct ( ) {
   ini_set("log_errors", 1);
              ini_set("error_log", "/tmp/mylogfile.log");
              error_log( "Hello, errors!" );
  }

}